const Koa = require('koa')
const Router = require('@koa/router')
const bodyParser = require('koa-bodyparser')

const app = new Koa()
const router = new Router()

// WebHook 接口
// 路由：WebHook 接口
router.post('/webhook', async ctx => {
    // Telegram的模拟Web App请求：
    var myHeaders = new Headers()
    myHeaders.append('User-Agent', 'Apifox/1.0.0 (https://apifox.com)')
    myHeaders.append('Content-Type', 'application/json')
    myHeaders.append('Accept', '*/*')
    myHeaders.append('Host', 'api.telegram.org')
    myHeaders.append('Connection', 'keep-alive')

    var raw = JSON.stringify({
        chat_id: 8015888418,
        text: '美好的一天henry-hook',
    })

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow',
    }

    console.log('📩 发送数据到 Telegram:', requestOptions)
    fetch(
        'https://api.telegram.org/bot7996507522:AAEtMBRvfLZbTQJxkyWmSuIJRoBtA0Tot2I/sendMessage',
        requestOptions
    )
        .then(response => response.text())
        .then(result => console.log(result))
        .catch(error => console.log('error', error))
    console.log('✅ 收到 WebHook:', ctx.request.body)
    ctx.body = { status: 'success' }
})

// sendData 接口
router.post('/sendData', async ctx => {
    console.log('📩 收到 sendData 请求:', ctx.request.body)

    // Telegram的模拟Web App请求：
    var myHeaders = new Headers()
    myHeaders.append('User-Agent', 'Apifox/1.0.0 (https://apifox.com)')
    myHeaders.append('Content-Type', 'application/json')
    myHeaders.append('Accept', '*/*')
    myHeaders.append('Host', 'api.telegram.org')
    myHeaders.append('Connection', 'keep-alive')

    var raw = JSON.stringify({
        chat_id: 8015888418,
        text: '美好的一天henry',
    })

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow',
    }

    console.log('📩 发送数据到 Telegram:', requestOptions)
    fetch(
        'https://api.telegram.org/bot7996507522:AAEtMBRvfLZbTQJxkyWmSuIJRoBtA0Tot2I/sendMessage',
        requestOptions
    )
        .then(response => response.text())
        .then(result => console.log(result))
        .catch(error => console.log('error', error))
    console.log('📩 收到 sendData 请求:', ctx.request.body)
    // 这里可以做签名验证、业务处理逻辑等
    ctx.status = 200
    ctx.body = { success: true, message: 'Webhook received' }
})

// get
router.get('/getData', async ctx => {
    // Telegram的模拟Web App请求：
    var myHeaders = new Headers()
    myHeaders.append('User-Agent', 'Apifox/1.0.0 (https://apifox.com)')
    myHeaders.append('Content-Type', 'application/json')
    myHeaders.append('Accept', '*/*')
    myHeaders.append('Host', 'api.telegram.org')
    myHeaders.append('Connection', 'keep-alive')

    var raw = JSON.stringify({
        chat_id: 8015888418,
        text: '美好的一天henry-get',
    })

    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow',
    }

    console.log('📩 发送数据到 Telegram:', requestOptions)
    fetch(
        'https://api.telegram.org/bot7996507522:AAEtMBRvfLZbTQJxkyWmSuIJRoBtA0Tot2I/sendMessage',
        requestOptions
    )
        .then(response => response.text())
        .then(result => console.log(result))
        .catch(error => console.log('error', error))
    console.log('📩 收到 WebHook 请求:', ctx.request)
    // 这里可以做签名验证、业务处理逻辑等
    ctx.status = 200
    ctx.body = { success: true, message: 'Webhook received' }
})

// 中间件
app.use(async (ctx, next) => {
    console.log(`📩 收到请求: ${ctx.method} ${ctx.url}`)
    await next()
})

//

app.use(bodyParser()) // 解析 JSON 请求体
app.use(router.routes()).use(router.allowedMethods())

// Telegram的 WebHook 端口：443 或 80 8443
const PORT = 8443
app.listen(PORT, () => {
    console.log(`🚀 WebHook Server running at http://localhost:${PORT}/`)
})
