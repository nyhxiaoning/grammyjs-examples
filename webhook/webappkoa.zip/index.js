const Koa = require('koa')
const Router = require('@koa/router')
const bodyParser = require('koa-bodyparser')

const app = new Koa()
const router = new Router()

// WebHook 接口
router.post('/webhook', async ctx => {
    console.log('📩 收到 WebHook 请求:', ctx.request.body)

    // 这里可以做签名验证、业务处理逻辑等
    ctx.status = 200
    ctx.body = { success: true, message: 'Webhook received' }
})

// sendData 接口
router.post('/sendData', async ctx => {
    console.log('📩 收到 sendData 请求:', ctx.request.body)

    // 这里可以做签名验证、业务处理逻辑等
    ctx.status = 200
    ctx.body = { success: true, message: 'Webhook received' }
})

// get
router.get('/getData', async ctx => {
    console.log('📩 收到 WebHook 请求:', ctx.request)
    // 这里可以做签名验证、业务处理逻辑等
    ctx.status = 200
    ctx.body = { success: true, message: 'Webhook received' }
})

// 中间件
app.use(async (ctx, next) => {
    console.log(`📩 收到请求: ${ctx.method} ${ctx.url}`)
    await next()
})

//

app.use(bodyParser()) // 解析 JSON 请求体
app.use(router.routes()).use(router.allowedMethods())

// Telegram的 WebHook 端口：443 或 80 8443
const PORT = 8443
app.listen(PORT, () => {
    console.log(`🚀 WebHook Server running at http://localhost:${PORT}/webhook`)
})
